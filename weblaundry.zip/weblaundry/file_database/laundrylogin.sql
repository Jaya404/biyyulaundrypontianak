-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2024 at 08:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundrylogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_images`
--

CREATE TABLE `dashboard_images` (
  `id` int(11) NOT NULL,
  `image_name` varchar(225) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dashboard_images`
--

INSERT INTO `dashboard_images` (`id`, `image_name`, `upload_date`) VALUES
(5, 'Paket1.png', '2024-11-06 12:12:44'),
(6, 'Menu_1.png', '2024-11-06 12:12:51'),
(8, 'Menu_2.png', '2024-11-06 12:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `konsumen`
--

CREATE TABLE `konsumen` (
  `kode_konsumen` varchar(12) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_konsumen` varchar(255) NOT NULL,
  `alamat_konsumen` text NOT NULL,
  `no_telp` varchar(14) NOT NULL,
  `tgl_pesan` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status_kons` varchar(225) NOT NULL,
  `kode_paket` varchar(225) NOT NULL,
  `kode_pewangi` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `konsumen`
--

INSERT INTO `konsumen` (`kode_konsumen`, `user_id`, `nama_konsumen`, `alamat_konsumen`, `no_telp`, `tgl_pesan`, `status_kons`, `kode_paket`, `kode_pewangi`) VALUES
('K001', 0, 'Jaya saputra', 'Jl. Kesehatan, Gg. Usaha Maju No. 9B', '085753874900', '2024-11-07 08:47:38', 'Penerima sudah mengambil pesanan anda', 'P003', 'Melati'),
('K002', 0, 'Egi Susanto', 'Jl. Prof. M.Yamin, Gg. Nirbaya, No. 7A', '081234567890', '2024-11-07 09:20:32', 'Penerima sedang menuju ke alamat anda', 'P003', 'Lavender'),
('K003', 0, 'Hery', 'Jl. Prof. M.Yamin, Gg. Pertiwi, No. 3C', '086352836270', '2024-11-07 09:21:23', 'Penerima sedang menuju ke alamat anda', 'P010', 'Lavender'),
('K004', 0, 'Aditya', 'Jl. Harapan Jaya, No. 32', '086352836275', '2024-11-07 09:21:54', 'Baru', 'P007', 'Sakura'),
('K005', 0, 'Haris', 'Jl. Prof. M.Yamin, Gg. Hidayah, No. 1A', '089178679008', '2024-11-07 09:22:04', 'Baru', 'P004', 'Mawar');

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `kode_paket` varchar(225) NOT NULL,
  `nama_paket` varchar(225) NOT NULL,
  `harga_paket` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`kode_paket`, `nama_paket`, `harga_paket`) VALUES
('P001', 'Cuci Setrika Wangi Minimal 3 Kg (6 Jam)', '5000'),
('P002', 'Cuci Setrika Wangi Minimal 3 Kg (1 Hari)', '2500'),
('P003', 'Cuci Setrika Wangi Minimal 3 Kg (3 Hari)', '2500'),
('P004', 'Cuci Lipat Rapi Minimal 3 Kg (2 Jam)', '4500'),
('P005', 'Cuci Lipat Rapi Minimal 3 Kg (6 Jam)', '3500'),
('P006', 'Cuci Lipat Rapi Minimal 3 Kg (1 Hari)', '2000'),
('P007', 'Setrika Wangi Minimal 3 Kg (12 Jam)', '3500'),
('P008', 'Setrika Wangi Minimal 3 Kg (1 Hari)', '2000'),
('P009', 'Cuci Saja Maximal 7 Kg (30 Menit)', '1500'),
('P010', 'Kering Saja Maximal 7 Kg (40 Menit)', '3000');

-- --------------------------------------------------------

--
-- Table structure for table `pewangi`
--

CREATE TABLE `pewangi` (
  `kode_pewangi` varchar(225) NOT NULL,
  `nama_pewangi` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pewangi`
--

INSERT INTO `pewangi` (`kode_pewangi`, `nama_pewangi`) VALUES
('PW1730959280', 'Sakura'),
('PW1730959351', 'Mawar'),
('PW1730959472', 'Lavender'),
('PW1730969609', 'Melati');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `kode_transaksi` varchar(225) NOT NULL,
  `kode_konsumen` varchar(225) NOT NULL,
  `kode_paket` varchar(225) NOT NULL,
  `tgl_masuk` datetime NOT NULL,
  `tgl_ambil` datetime NOT NULL,
  `berat` int(11) NOT NULL,
  `grand_total` int(11) NOT NULL,
  `bayar` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL,
  `kode_pewangi` varchar(225) DEFAULT NULL,
  `pcs_pakaian` varchar(225) NOT NULL,
  `rak` varchar(225) NOT NULL,
  `tgl_diterima` datetime NOT NULL,
  `jarak` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`kode_transaksi`, `kode_konsumen`, `kode_paket`, `tgl_masuk`, `tgl_ambil`, `berat`, `grand_total`, `bayar`, `status`, `kode_pewangi`, `pcs_pakaian`, `rak`, `tgl_diterima`, `jarak`) VALUES
('TR20241107001', 'K001', 'P003', '2024-11-07 04:14:04', '2024-11-07 10:15:10', 3, 7000, 'Lunas', 'Selesai', 'Melati', 'kemeja 3 pcs, jaket 4 pcs, baju 10 pcs....', '5', '2024-11-10 16:14:00', 0.00),
('TR20241107002', 'K002', 'P003', '2024-11-07 04:23:43', '2024-11-07 10:24:48', 8, 9000, 'Lunas', 'Selesai', 'Lavender', 'kemeja 5 pcs, jaket 5 pcs, baju 11, celana 9 pcs....', '7', '2024-11-10 17:18:00', 0.00),
('TR20241107003', 'K003', 'P010', '2024-11-07 16:25:37', '2024-11-07 10:29:25', 7, 20000, 'Lunas', 'menuju ke alamat anda', 'Lavender', 'kemeja 8 pcs, jaket 5 pcs, baju 15, celana 11 pcs....', '3', '2024-11-07 16:50:00', 0.00),
('TR20241107004', 'K004', 'P007', '2024-11-07 04:33:03', '2024-11-07 10:37:47', 3, 10000, 'Lunas', 'sedang di lipat', 'Sakura', 'kemeja 7 pcs, jaket 2 pcs, baju 15, celana 8 pcs....', '8', '2024-11-08 07:15:00', 0.00),
('TR20241107005', 'K005', 'P004', '2024-11-07 16:34:14', '2024-11-07 10:37:55', 3, 13000, 'Lunas', 'Baru', 'Mawar', 'kemeja 9 pcs, jaket 2 pcs, baju 12, celana 15 pcs....', '6', '2024-11-07 18:40:00', 0.00),
('TR20241125006', 'K004', 'P002', '2024-11-25 18:28:51', '0000-00-00 00:00:00', 6, 20000, 'Belum Lunas', 'Baru', 'Mawar', 'kemeja 3 pcs, jaket 4 pcs, baju 10 pcs....', '6', '2024-11-25 18:29:00', 0.00),
('TR20241125007', 'K002', 'P004', '2024-11-25 18:30:38', '0000-00-00 00:00:00', 2, 14000, 'Belum Lunas', 'Baru', 'Melati', 'kemeja 5 pcs, jaket 5 pcs, baju 11, celana 9 pcs....', '4', '2024-11-25 18:31:00', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(4, 'Jaya', 'sjaya6460@gmail.com', 'images_(20).jpeg', '$2y$10$q/.h5ZTobzO4.Th7ndss2.iWjQZC3mdWA725bf8VSsQKdbUcJrSD6', 1, 1, 1716298940),
(5, 'Asep oioi', 'asepoioi@gmail.com', 'IMG_20210618_063900.jpg', '$2y$10$2PCt8ORuNAPhT5CmEGaAs.GarlTb4VIqwFQ5wWQlrbUvWShBTFoBC', 2, 1, 1716299642),
(6, 'egi', 'egi@gmail.com', 'default.jpg', '$2y$10$4ADYiBcu8KbAzQ7/3MynYOUaFsXljafyUJ3PgVSMPZfWjdGhkCzgq', 2, 0, 1716542149),
(7, 'mawang', 'mawang@gmail.com', 'default.jpg', '$2y$10$AclfLcqbhq28EE8G8WAn2OVIfq2oXz7ziHhgyWCuN20YNsBRJosvW', 2, 0, 1716550531),
(8, 'budi sutomo', 'budi@gmail.com', 'default.jpg', '$2y$10$pZ5Wjm3mHzivXfvR93kKH.QbhSLm5azvLVWRAf2ZEtx48.mm/oaym', 2, 1, 1716550736),
(9, 'ihsan', 'ihsan@gmail.com', 'default.jpg', '$2y$10$qYZa3K2l4sY2me.rwtP7bObw285k1kw2S79Ag1ge3X0DOUrTYFXV.', 2, 1, 1728205956),
(10, 'messi', 'messi@gmail.com', 'default.jpg', '$2y$10$GAAoWXtSeIlcMl00AAaatugoV8LjDYmj4Ra9IU7DcQzEq0JkbR0P.', 2, 1, 1728741781),
(11, 'aditya', 'aditya@gmail.com', 'default.jpg', '$2y$10$K8ad2vUMWB53dIflzFsW5.FSxuBDVda.ojtDePT2Xs4u.biS4outS', 2, 1, 1729430023),
(12, 'Egi Susanto', 'egisusanto@gmail.com', 'default.jpg', '$2y$10$X3fQzF5gUIt9AaZmURhydeNvTOpydeQYFfSvHH81ZTLD.Aw5ReGzm', 2, 1, 1730974144);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2),
(6, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'User'),
(3, 'Menu'),
(7, 'Pesan Laundry'),
(8, 'Pesan Jasa Laundry');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', 1),
(4, 3, 'Menu Management', 'menu', 'fas fa-fw fa-folder', 1),
(5, 3, 'Submenu Management', 'menu/submenu', 'fas fa-fw fa-folder-open', 1),
(16, 1, 'Data Paket', 'admin/v_paket', 'fas fa-fw fa-box', 1),
(17, 1, 'Data Pewangi', 'admin/v_pewangi', 'fas fa-fw fa-tint', 1),
(18, 1, 'Data Transaksi', 'admin/t_transaksi', 'fas fa-fw fa-money-bill-wave', 1),
(23, 2, 'Dashboard Laundry', 'user/dashboard_laundry', 'fas fa-fw fa-tachometer-alt', 1),
(25, 2, 'Pesan Antar Jemput', 'user/v_konsumen', 'fas fa-fw fa-user-plus', 1),
(26, 2, 'Riwayat Pesanan', 'user/riwayat_pesanan', 'fas fa-fw fa-chart-area', 1),
(27, 2, 'Profil Saya', 'user', 'fas fa-fw fa-user', 1),
(28, 2, 'Edit Profil', 'user/edit', 'fas fa-fw fa-user-edit', 1),
(29, 2, 'Ubah Password', 'user/changepassword', 'fas fa-fw fa-key', 1),
(32, 1, 'Role', 'admin/role', 'fas fa-fw fa-user-tie', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dashboard_images`
--
ALTER TABLE `dashboard_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `konsumen`
--
ALTER TABLE `konsumen`
  ADD PRIMARY KEY (`kode_konsumen`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`kode_paket`);

--
-- Indexes for table `pewangi`
--
ALTER TABLE `pewangi`
  ADD PRIMARY KEY (`kode_pewangi`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`kode_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dashboard_images`
--
ALTER TABLE `dashboard_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
