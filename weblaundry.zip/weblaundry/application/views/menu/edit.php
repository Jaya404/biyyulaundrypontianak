<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    <?= $this->session->flashdata('message'); ?>

    <form action="<?= base_url('menu/edit/' . $menu_item['id']); ?>" method="post">
        <div class="form-group">
            <label for="menu">Menu Name</label>
            <input type="text" class="form-control" id="menu" name="menu" value="<?= $menu_item['menu']; ?>" placeholder="Menu name">
        </div>
        <button type="submit" class="btn btn-primary" style="background-color: #3B6026;">Update Menu</button>
    </form>

</div>
<!-- /.container-fluid -->