<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= form_error('title', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    <?= $this->session->flashdata('message'); ?>

    <form action="<?= base_url('menu/edit_submenu/' . $submenu_item['id']); ?>" method="post">
        <div class="form-group">
            <label for="title">Submenu Title</label>
            <input type="text" class="form-control" id="title" name="title" value="<?= $submenu_item['title']; ?>" placeholder="Submenu title">
        </div>
        <div class="form-group">
            <label for="menu_id">Menu</label>
            <select name="menu_id" id="menu_id" class="form-control">
                <option value="">Select Menu</option>
                <?php foreach ($menu as $m) : ?>
                    <option value="<?= $m['id']; ?>" <?= $m['id'] == $submenu_item['menu_id'] ? 'selected' : ''; ?>><?= $m['menu']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="url">Submenu URL</label>
            <input type="text" class="form-control" id="url" name="url" value="<?= $submenu_item['url']; ?>" placeholder="Submenu URL">
        </div>
        <div class="form-group">
            <label for="icon">Submenu Icon</label>
            <input type="text" class="form-control" id="icon" name="icon" value="<?= $submenu_item['icon']; ?>" placeholder="Submenu Icon">
        </div>
        <div class="form-group">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" name="is_active" id="is_active" <?= $submenu_item['is_active'] ? 'checked' : ''; ?>>
                <label class="form-check-label" for="is_active">
                    Active?
                </label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary" style="background-color: #3B6026;">Update Submenu</button>
    </form>

</div>
<!-- /.container-fluid -->