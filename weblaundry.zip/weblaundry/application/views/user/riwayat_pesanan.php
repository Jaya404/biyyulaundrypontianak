<?php if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Selamat!</strong> <?= $this->session->flashdata('info') ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php } ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h6 mb-3 text-gray-800"><?= $title; ?></h1>

    <div class="card shadow mb-4">
        <div class="card-header py-1">
            <h6 class="m-0 font-weight-bold text-primary"><?= $title; ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-bordered" id="dataTable" style="font-size: 10px; width: 170%;" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Masuk</th>
                            <th>Kode Transaksi</th>
                            <th>Konsumen</th>
                            <th>Alamat</th>
                            <th>No. Telepon/WA</th>
                            <th>Paket</th>
                            <th>Pewangi</th>
                            <th>Berat (kg)</th>
                            <th>Total Pakaian</th>
                            <th>No. Rak Pakaian</th>
                            <th>Tanggal Diterima</th>
                            <th>Grand Total</th>
                            <th>Status Bayar</th>
                            <th>Status</th>
                            <?php if ($user['role_id'] == 1) : ?>
                                <th>Opsi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    foreach ($riwayat as $row) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $row->tgl_masuk; ?></td>
                            <td><?= $row->kode_transaksi; ?></td>
                            <td><?= $row->nama_konsumen; ?></td>
                            <td><?= $row->alamat_konsumen; ?></td>
                            <td><?= $row->no_telp; ?></td>
                            <td><?= $row->nama_paket; ?></td>
                            <td><?= $row->kode_pewangi; ?></td>
                            <td><?= $row->berat; ?></td>
                            <td><?= $row->pcs_pakaian; ?></td>
                            <td><?= $row->rak; ?></td>
                            <td><?= $row->tgl_diterima; ?></td>
                            <td><?= "Rp. " . number_format($row->grand_total, 0, '.', '.'); ?></td>
                            <td><?= $row->bayar; ?></td>
                            <td>
                                <?php 
                                // Set an array for the status options
                                $statusOptions = [
                                    "Baru",
                                    "sedang di cuci",
                                    "selesai di cuci",
                                    "sedang di keringkan",
                                    "selesai di keringkan",
                                    "sedang di setrika",
                                    "selesai di setrika",
                                    "sedang di lipat",
                                    "selesai di lipat",
                                    "sedang di kemas",
                                    "selesai di kemas",
                                    "Menunggu pengirim",
                                    "menuju ke alamat anda",
                                    "Pesanan sudah sampai",
                                    "Selesai"
                                ];
                                
                                // Check if the user role is admin
                                if ($user['role_id'] == 1) { 
                                    // If admin, show a dropdown
                                    ?>
                                    <select name="status" class="badge badge-primary status" style="font-size: 8px;">
                                        <?php foreach ($statusOptions as $option) : ?>
                                            <option value="<?= $row->kode_transaksi . $option ?>" <?= ($row->status == $option) ? 'selected' : '' ?>>
                                                <?= $option ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php } else { 
                                    // If not admin, show the current status as a badge
                                    ?>
                                    <span class="badge badge-primary" style="font-size: 8px;"><?= $row->status; ?></span>
                                <?php } ?>
                            </td>

                            <?php if ($user['role_id'] == 1) : ?>
                                <td>
                                    <?php if ($row->status != 'Selesai') { ?>
                                        <a href="<?= base_url('admin/edit_transaksi/' . $row->kode_transaksi); ?>" class="btn btn-success btn-sm" style="font-size: 7px; padding: 2px 6px;">Edit</a>
                                    <?php } ?>
                                    <a href="<?= base_url('admin/nota/' . $row->kode_transaksi); ?>" class="btn btn-primary btn-sm" style="font-size: 7px; padding: 2px 6px;">Nota</a>
                                    <a href="<?= base_url('admin/delete_transaksi/' . $row->kode_transaksi); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi ini?');" class="btn btn-danger btn-sm" style="font-size: 7px; padding: 2px 6px;">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script>
    $('.status').change(function() {
        var status = $(this).val(); // Get the selected value
        var kt = status.substr(0, 13); // Extract kode_transaksi
        var stt = status.substr(13); // Extract status

        $.ajax({
            url: "<?= base_url() ?>admin/update_status",
            method: "post",
            data: {
                kt: kt,
                stt: stt
            },
            success: function(response) {
                // You can do something on success if needed
                location.reload(); // Reload the page to reflect changes
            },
            error: function() {
                alert("Terjadi kesalahan saat memperbarui status. Silakan coba lagi."); // Alert if there's an error
            }
        });
    });
</script>
