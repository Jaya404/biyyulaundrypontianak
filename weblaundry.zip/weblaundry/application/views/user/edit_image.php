<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= $this->session->flashdata('message'); ?>

    <!-- Form for editing the image --><form action="<?= base_url('user/update_image/' . $image['id']); ?>" method="post" enctype="multipart/form-data">
     <form action="<?= base_url('user/update_image/' . $image['id']); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="image">Upload New Image</label>
            <input type="file" class="form-control-file" id="image" name="image" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Image</button>
    </form>
</div>
