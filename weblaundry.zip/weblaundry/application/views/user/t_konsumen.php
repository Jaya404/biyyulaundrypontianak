<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="myForm" method="post" action="<?= base_url('user/simpan'); ?>">
                <div class="form-group">
                    <input type="text" name="kode_konsumen" value="<?= $kode_konsumen; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <input type="text" name="nama_konsumen" class="form-control" placeholder="Nama Konsumen" required>
                </div>
                <div class="form-group">
                    <textarea name="alamat_konsumen" cols="30" rows="5" class="form-control" placeholder="Alamat" required></textarea>
                </div>
                <div class="form-group">
                    <?php if ($this->session->flashdata('message')): ?>
                        <?= $this->session->flashdata('message'); ?>
                    <?php endif; ?>
                    <input type="number" name="no_telp" class="form-control" placeholder="No. Telepon/WA" required>
                </div>
                <div class="form-group">
                <label for="kode_paket">Tidak pilih paket, jangan isi!</label>
                    <select name="kode_paket" id="paket" class="form-control">
                        <option value="" selected> - pilih paket - </option>
                        <?php foreach ($paket as $row): ?>
                            <option value="<?= $row->kode_paket ?>"> <?= $row->nama_paket; ?> </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select name="kode_pewangi" class="form-control" required>
                        <option value="" selected> - pilih pewangi - </option>
                        <?php foreach ($pewangi as $row): ?>
                            <option value="<?= $row->nama_pewangi; ?>"> <?= $row->nama_pewangi; ?> </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" hidden>
                    <input type="text" name="tgl_pesan" id="tgl_pesan" class="form-control" readonly>
                </div>

                <div class="form-group" hidden>
                    <input type="text" name="status_kons" value="Baru" class="form-control" placeholder="Status" readonly>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn" style="background-color: #3B6026;">
                        <span style="color: white;">Simpan</span>
                    </button>
                    <a href="<?= base_url('user/v_konsumen') ?>" class="btn btn-danger"> Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>
    $(document).ready(function() {
        // Additional client-side validation
        $('form').submit(function(e) {
            var phone = $('input[name="no_telp"]').val();
            if (phone.length < 10) {
                alert("Nomor telepon harus lebih dari 10 digit.");
                e.preventDefault();
            }
        });

        // Ambil tanggal saat ini
        var today = new Date();
        var date = today.getFullYear() + '-' + ('0' + (today.getMonth() + 1)).slice(-2) + '-' + ('0' + today.getDate()).slice(-2);
        var time = ('0' + today.getHours()).slice(-2) + ':' + ('0' + today.getMinutes()).slice(-2) + ':' + ('0' + today.getSeconds()).slice(-2);
        var dateTime = date + ' ' + time;

        // Masukkan tanggal dan waktu ke dalam input hidden
        $('#tgl_pesan').val(dateTime);

        // Add confirmation dialog on form submit
        $('#myForm').on('submit', function(e) {
            if (!confirm("Apakah Anda yakin ingin menyimpan data ini?")) {
                e.preventDefault(); // Prevent form submission
            }
        });
    });
</script>
