<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title;  ?></h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form method="post" action="<?= base_url('user/update'); ?>">
                <div class="form-group">
                    <input type="text" name="kode_konsumen" value="<?= $konsumen['kode_konsumen']; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <input type="text" name="nama_konsumen" value="<?= $konsumen['nama_konsumen']; ?>" class="form-control" placeholder="Nama Konsumen" required>
                </div>
                <div class="form-group">
                    <textarea name="alamat_konsumen" cols="30" rows="5" class="form-control" placeholder="Alamat" required><?= $konsumen['alamat_konsumen']; ?></textarea>
                </div>
                <div class="form-group">
                    <?php if ($this->session->flashdata('message')): ?>
                        <?= $this->session->flashdata('message'); ?>
                    <?php endif; ?>
                    <input type="number" name="no_telp" class="form-control" value="<?= $konsumen['no_telp']; ?>" placeholder="No. Telpon" required>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <a href="<?= base_url('user/v_konsumen') ?>" class="btn btn-danger">Batal</a>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->