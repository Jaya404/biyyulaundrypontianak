<style>
    .badge-danger {
        background-color: red !important; /* Warna merah untuk 'Baru' */
        color: white !important; /* Warna teks putih */
    }
    .badge-warning {
        background-color: yellow !important; /* Warna kuning untuk 'Penerima sedang menuju ke alamat anda' */
        color: black !important; /* Warna teks putih */
    }
    .badge-success {
        background-color: green !important; /* Warna hijau untuk 'Penerima sudah mengambil pesanan anda' */
        color: white !important; /* Warna teks putih */
    }
</style>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h6 mb-3 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-md-12">
            <a href="<?= base_url('user/t_konsumen'); ?>" class="btn" style="background-color: #3B6026; font-size: 12px;"><span style="color: white;">Pesan Antar Jemput</span></a>
        </div>
    </div>
    <br>
    <?php if ($this->session->flashdata('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" style="font-size: 12px;">
            <?= $this->session->flashdata('message'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-header py-1">
            <h6 class="m-0 font-weight-bold text-primary"><?= $title; ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-bordered" id="dataTable" style="font-size: 12px;" width="130%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Pesanan</th>
                            <th>Kode</th>
                            <th>Nama Konsumen</th>
                            <th>Alamat</th>
                            <th>No. Telepon/WA</th>
                            <th>Paket</th>
                            <th>Pewangi</th>
                            <th>Status</th>
                            <?php if ($user['role_id'] == 1) : ?>
                                <th>Opsi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($konsumen as $row) {
                            $no_telp = $row->no_telp; 
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= date('d-m-Y H:i:s', strtotime($row->tgl_pesan)); ?></td>
                                <td><?= $row->kode_konsumen; ?></td>
                                <td><?= $row->nama_konsumen; ?></td>
                                <td><?= $row->alamat_konsumen; ?></td>
                                <td><?= $no_telp; ?></td>
                                <td><?= $row->nama_paket; ?></td>
                                <td><?= $row->kode_pewangi; ?></td>
                                <td>
                                    <?php if ($user['role_id'] == 1) { ?>
                                        <select name="status_kons" data-kode="<?= $row->kode_konsumen; ?>" 
                                                class="badge badge-<?= $row->status_kons == 'Baru' ? 'danger' : 
                                                ($row->status_kons == 'Penerima sedang menuju ke alamat anda' ? 'warning' : 'success') ?> status" 
                                                style="font-size: 8px;">
                                            <option value="Baru" <?= $row->status_kons == "Baru" ? "selected" : ""; ?>>Baru</option>
                                            <option value="Penerima sedang menuju ke alamat anda" <?= $row->status_kons == "Penerima sedang menuju ke alamat anda" ? "selected" : ""; ?>>Penerima sedang menuju ke alamat anda</option>
                                            <option value="Penerima sudah mengambil pesanan anda" <?= $row->status_kons == "Penerima sudah mengambil pesanan anda" ? "selected" : ""; ?>>Penerima sudah mengambil pesanan anda</option>
                                        </select>
                                    <?php } else { ?>
                                        <span class="badge badge-<?= $row->status_kons == 'Baru' ? 'danger' : 
                                        ($row->status_kons == 'Penerima sedang menuju ke alamat anda' ? 'warning' : 'success') ?>" 
                                        style="font-size: 8px;"><?= $row->status_kons; ?></span>
                                    <?php } ?>
                                </td>


                                <?php if ($user['role_id'] == 1) : ?>
                                    <td>
                                        <a href="<?= base_url() ?>user/edit_konsumen/<?= $row->kode_konsumen; ?>" class="btn btn-success btn-sm" style="font-size: 12px;">Edit</a>
                                         <button class="btn btn-danger btn-sm delete-status" data-kode="<?= $row->kode_konsumen; ?>" style="font-size: 12px;">Delete</button>
                                    </td>

                                <?php endif; ?>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script>
    $('.status').change(function() {
        var kode_konsumen = $(this).data('kode');
        var status_kons = $(this).val();

        $.ajax({
            url: "<?= base_url() ?>user/status_konsumen",
            method: "post",
            data: {
                kode_konsumen: kode_konsumen,
                status_kons: status_kons
            },
            success: function(response) {
                alert('Status berhasil diperbarui!');
                location.reload();
            }
        });
    });
</script>

<script>
    $('.delete-status').click(function() {
        var kode_konsumen = $(this).data('kode');
        if (confirm('Yakin ingin menghapus data ini?')) {
            $.ajax({
                url: "<?= base_url() ?>user/delete_konsumen",
                method: "post",
                data: {
                    kode_konsumen: kode_konsumen
                },
                success: function(response) {
                    alert('Data berhasil dihapus!');
                    location.reload();
                },
                error: function() {
                    alert('Gagal menghapus data.');
                }
            });
        }
    });
</script>

