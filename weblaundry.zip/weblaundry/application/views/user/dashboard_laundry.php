<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


    <?php if ($user['role_id'] == 1) : ?>
    <?= $this->session->flashdata('message'); ?>

    <!-- Form Upload Gambar -->
    <form action="<?= base_url('user/upload_image'); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="image">Upload Image</label>
            <input type="file" class="form-control-file" id="image" name="image" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
    <br>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <a href="<?= base_url('user/v_konsumen'); ?>" class="btn" style="background-color: #3B6026; font-size: 12px;"><span style="color: white;">Daftar Antar Jemput Disini</span></a>
        </div>
    </div>

    <div class="row mt-4">
        <?php foreach ($images as $image): ?>
            <div class="col-md-3 mb-4">
                <!-- Card for each image -->
                <div class="card">
                    <img src="<?= base_url('assets/img/dashboard/' . $image['image_name']); ?>" alt="Image" class="card-img-top">
                    <?php if ($user['role_id'] == 1) : ?>
                    <div class="card-body">
                        <!-- Edit Button -->
                        <a href="<?= base_url('user/edit_image/' . $image['id']); ?>" class="btn btn-warning btn-sm w-100 mb-2">
                            Edit
                        </a>
                        <!-- Delete Button -->
                        <a href="<?= base_url('user/delete_image/' . $image['id']); ?>" class="btn btn-danger btn-sm w-100" onclick="return confirm('Are you sure you want to delete this image?');">
                            Delete
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
