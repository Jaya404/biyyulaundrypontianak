<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form method="post" action="<?= base_url('admin/update'); ?>">
                <div class="form-group">
                    <input type="text" name="kode_paket" value="<?= $data['kode_paket']; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <input type="text" name="nama_paket" value="<?= $data['nama_paket']; ?>" class="form-control" placeholder="Pilih Paket" required>
                </div>
                <div class="form-group">
                    <input type="number" name="harga_paket" value="<?= $data['harga_paket']; ?>" class="form-control" placeholder="Harga Paket" required>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="background-color: #3B6026;">Update</button>
                    <a href="<?= base_url('admin/v_paket') ?>" class="btn btn-danger"> Batal</a>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
