<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="myForm" method="post" action="<?= base_url('admin/update_pewangi'); ?>">
                <div class="form-group">
                    <!-- Kode Pewangi -->
                    <input type="text" name="kode_pewangi" value="<?= $pewangi->kode_pewangi; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <!-- Nama Pewangi -->
                    <input type="text" name="nama_pewangi" value="<?= $pewangi->nama_pewangi; ?>" class="form-control" placeholder="Nama Pewangi" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn" style="background-color: #3B6026;">
                        <span style="color: white;">Simpan</span>
                    </button>
                    <a href="<?= base_url('admin/v_pewangi'); ?>" class="btn btn-danger"> Batal</a>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->
