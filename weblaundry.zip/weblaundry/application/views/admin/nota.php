<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Laundry</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f7f7f7;
        }

        .nota-container {
            width: 80mm;
            background-color: #fff;
            padding: 20px;
            margin: auto;
            border: 1px solid #ddd;
        }

        .nota-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .nota-header h2 {
            margin: 0;
        }

        .nota-details {
            margin-bottom: 15px;
        }

        .nota-details p {
            margin: 0;
            line-height: 1.5;
        }

        .nota-footer {
            text-align: center;
            margin-top: 20px;
        }

        .print-button {
            display: block;
            width: 10%;
            padding: 10px;
            margin: 20px auto;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            text-align: center;
            font-size: 16px;
        }

        .print-button:hover {
            background-color: #0056b3;
        }

        @media print {
            body {
                background-color: #fff;
                -webkit-print-color-adjust: exact;
            }

            .nota-container {
                width: 80mm;
                border: none;
            }

            .print-button {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="nota-container">
        <div class="nota-header">
            <h2>Biyyu Laundry Pontianak</h2>
            <p>Jl. Perdamaian No. 2, Kota Baru Ujung Pontianak</p>
            <p>Telp: 081324570620</p>
        </div>

        <div class="nota-details">
            <p><strong>Tanggal:</strong> <?= $row->tgl_masuk; ?></p>
            <p><strong>Kode Transaksi:</strong> <?= $row->kode_transaksi; ?></p>
            <p><strong>Nama Konsumen:</strong> <?= $row->nama_konsumen; ?></p>
            <p><strong>Alamat:</strong> <?= $row->alamat_konsumen; ?></p>
            <p><strong>No. Telpon/WA:</strong> <?= $row->no_telp; ?></p>
            <p>--------------------------------------------------------</p>
            <p><strong>Paket:</strong> <?= $row->nama_paket; ?></p>
            <p><strong>Pewangi:</strong> <?= $row->kode_pewangi; ?></p>
            <p><strong>Berat (Kg):</strong> <?= $row->berat; ?></p>
            <p><strong>Total Pakaian:</strong> <?= $row->pcs_pakaian; ?></p>
            <p><strong>No. Rak Pakaian:</strong> <?= $row->rak; ?></p>
            <p><strong>Total Harga:</strong> <?= "Rp. " . number_format($row->grand_total, 0, '.', '.'); ?></p>
            <p>--------------------------------------------------------</p>
        </div>

        <div class="nota-footer">
            <p>Terima Kasih!</p>
        </div>
    </div>

    <button class="print-button" onclick="window.print()">Cetak Nota</button>
</body>

</html>
