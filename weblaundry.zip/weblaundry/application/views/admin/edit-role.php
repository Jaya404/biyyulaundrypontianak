<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-lg-6">
            <?= form_error('role', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
            <?= $this->session->flashdata('message'); ?>

            <form action="<?= base_url('admin/updateRole'); ?>" method="post">
                <input type="hidden" name="role_id" value="<?= $role['id']; ?>">
                <div class="form-group">
                    <label for="role">Role Name</label>
                    <input type="text" class="form-control" id="role" name="role" value="<?= $role['role']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Role</button>
                <a href="<?= base_url('admin/role'); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->