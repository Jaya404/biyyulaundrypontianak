<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h6 mb-3 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-md-12">
            <a href="<?= base_url('admin/t_paket'); ?>" class="btn" style="background-color: #3B6026; font-size: 12px;"><span style="color: white;">Tambah Paket</span></a>
        </div>
    </div>
    <br>
    <?php if (!empty($this->session->flashdata('info'))) { ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" style="font-size: 12px;">
            <strong>Selamat!</strong> <?= $this->session->flashdata('info') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php } ?>

    <div class="card shadow mb-4">
        <div class="card-header py-1">
            <h6 class="m-0 font-weight-bold text-primary"><?= $title; ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-bordered" id="dataTable" style="font-size: 12px;" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Paket</th>
                            <th>Nama Paket</th>
                            <th>Harga Paket</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($paket as $row) { 
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $row->kode_paket; ?></td>
                                <td><?= $row->nama_paket; ?></td>
                                <td><?= "Rp. " . number_format($row->harga_paket, 0, '.', '.'); ?></td>
                                <td>
                                    <a href="<?= base_url() ?>admin/e_paket/<?= $row->kode_paket; ?>" class="btn btn-success btn-sm" style="font-size: 12px;">Edit</a>
                                    <a href="<?= base_url() ?>admin/delete/<?= $row->kode_paket; ?>" class="btn btn-danger btn-sm" style="font-size: 12px;" onclick="return confirm('Yakin ingin menghapus data paket ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
