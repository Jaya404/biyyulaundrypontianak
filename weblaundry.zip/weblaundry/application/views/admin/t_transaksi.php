<?php
date_default_timezone_set('Asia/jakarta');
$tgl_masuk = date('Y-m-d h:i:s');
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?php if (!empty($this->session->flashdata('info'))) { ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Selamat!</strong> <?= $this->session->flashdata('info') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php } ?>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="transaksiForm" method="post" action="<?= base_url('admin/simpan_transaksi'); ?>">
                <div class="form-group">
                    <input type="text" name="kode_transaksi" value="<?= "TR" . date('Ymd') . $kode_transaksi; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <select name="kode_konsumen" class="form-control" required>
                        <option value="" selected> - pilih konsumen - </option>
                        <?php foreach ($konsumen as $row) { ?>
                            <option value="<?= $row->kode_konsumen ?>"> <?= $row->nama_konsumen; ?> </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">
                <label for="kode_paket">Tidak pilih paket, jangan isi!</label>
                    <select name="kode_paket" id="paket" class="form-control">
                        <option value="" selected> - pilih paket - </option>
                        <?php foreach ($paket as $row) { ?>
                            <option value="<?= $row->kode_paket ?>"> <?= $row->nama_paket; ?> </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">
                    <select name="kode_pewangi" class="form-control" required>
                        <option value="" selected> - pilih pewangi - </option>
                        <?php foreach ($pewangi as $row) { ?>
                            <option value="<?= $row->nama_pewangi; ?>"> <?= $row->nama_pewangi; ?> </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">
                    <input type="text" id="harga" class="form-control" placeholder="Harga Paket" readonly>
                </div>

                <div class="form-group">
                    <input type="number" name="berat" id="berat" class="form-control" placeholder="Berat (kg)" required>
                </div>

                <div class="form-group">
                    <input type="text" name="pcs_pakaian" class="form-control" placeholder="Jenis pakaian dan berapa pcs yang masuk">
                </div>

                <div class="form-group">
                    <input type="number" name="rak" class="form-control" placeholder="No. Rak Pakaian">
                </div>

                <div class="form-group">
                    <input type="number" name="jarak" id="jarak" class="form-control" placeholder="Masukkan Jarak (km)">
                </div>

                <div class="form-group">
                    <label for="tgl_diterima">Tanggal Diterima</label>
                    <input type="datetime-local" name="tgl_diterima" class="form-control">
                </div>

                <div class="form-group">
                    <input type="number" name="grand_total" id="grand_total" class="form-control" placeholder="Total harga">
                </div>

                <div class="form-group" hidden>
                    <input type="text" name="tgl_masuk" id="tgl_masuk" class="form-control" readonly>
                </div>

                <div class="form-group">
                    <select name="bayar" class="form-control">
                        <option value=""> - Pilih Status Bayar - </option>
                        <option value="Lunas"> Lunas</option>
                        <option value="Belum Lunas"> Belum Lunas</option>
                    </select>
                </div>

                <div class="form-group" hidden>
                    <input type="text" name="status" value="Baru" class="form-control" placeholder="Status" readonly>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn" style="background-color: #3B6026;">
                        <span style="color: white;">Simpan</span>
                    </button>
                    <a href="<?= base_url('admin') ?>" class="btn btn-danger"> Batal</a>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>
$(document).ready(function() {
    var today = new Date();
    var date = today.getFullYear() + '-' + ('0' + (today.getMonth() + 1)).slice(-2) + '-' + ('0' + today.getDate()).slice(-2);
    var time = ('0' + today.getHours()).slice(-2) + ':' + ('0' + today.getMinutes()).slice(-2) + ':' + ('0' + today.getSeconds()).slice(-2);
    var dateTime = date + ' ' + time;

    $('#tgl_masuk').val(dateTime);

    $('#transaksiForm').on('submit', function(e) {
        if (!confirm("Apakah Anda yakin ingin menyimpan data transaksi ini?")) {
            e.preventDefault();
        }
    });

    $('#paket').change(function() {
        var kode_paket = $(this).val();

        $.ajax({
            url: '<?= base_url() ?>admin/getHargaPaket',
            data: { kode_paket: kode_paket },
            method: 'post',
            dataType: 'JSON',
            success: function(hasil) {
                $('#harga').val(hasil.harga_paket);
                calculateTotal();
            }
        });
    });

    $('#berat, #jarak').keyup(function() {
        calculateTotal();
    });

    function calculateTotal() {
        var berat = parseFloat($('#berat').val()) || 0;
        var harga = parseFloat($('#harga').val()) || 0;
        var jarak = parseFloat($('#jarak').val()) || 0;
        var biaya_tambahan = 0;

        if (jarak >= 5) {
            biaya_tambahan = 5000;
        } else if (jarak >= 3) {
            biaya_tambahan = 3000;
        } else if (jarak >= 2) {
            biaya_tambahan = 2000;
        }

        var grand_total = (harga * berat) + biaya_tambahan;
        $('#grand_total').val(grand_total);
    }
});

</script>
