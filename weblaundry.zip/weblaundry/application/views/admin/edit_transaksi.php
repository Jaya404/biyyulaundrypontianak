<?php
date_default_timezone_set('Asia/jakarta');
$tgl_masuk = date('Y-m-d h:i:s');
?>
<?php
if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Selamat!</strong> <?= $this->session->flashdata('info') ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php }
?>

<div class="container-fluid">
    <h6 class="m-0 font-weight-bold text-primary"><?= $title; ?></h6>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form method="post" action="<?= base_url('admin/update_transaksi'); ?>">
                <div class="form-group">
                    <input type="text" name="kode_transaksi" value="<?= $transaksi['kode_transaksi']; ?>" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <select name="kode_konsumen" class="form-control" required>
                        <?php
                        if (is_iterable($konsumen)) {
                            foreach ($konsumen as $kons) {
                                if ($transaksi['kode_konsumen'] == $kons->kode_konsumen) { ?>
                                    <option value="<?= $kons->kode_konsumen ?>" selected> <?= $kons->nama_konsumen ?></option>
                                <?php } else { ?>
                                    <option value="<?= $kons->kode_konsumen ?>"> <?= $kons->nama_konsumen ?></option>
                        <?php }
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <select name="kode_paket" id="paket" class="form-control" required>
                        <?php
                        if (is_iterable($paket)) {
                            foreach ($paket as $pkt) {
                                if ($transaksi['kode_paket'] == $pkt->kode_paket) { ?>
                                    <option value="<?= $pkt->kode_paket ?>" selected> <?= $pkt->nama_paket ?></option>
                                <?php } else { ?>
                                    <option value="<?= $pkt->kode_paket ?>"> <?= $pkt->nama_paket ?></option>
                        <?php }
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <select name="kode_pewangi" class="form-control" required>
                        <option value="" selected> - pilih pewangi - </option>
                        <?php foreach ($pewangi as $row) { ?>
                            <option value="<?= $row->nama_pewangi; ?>" <?= $transaksi['kode_pewangi'] == $row->nama_pewangi ? 'selected' : ''; ?>> <?= $row->nama_pewangi; ?> </option>
                        <?php } ?>
                    </select>
                </div>


                <div class="form-group">
                    <input type="text" id="harga" class="form-control" value="<?= $transaksi['harga_paket']; ?>" placeholder="Harga Paket">
                </div>

                <div class="form-group">
                    <input type="number" name="berat" id="berat" class="form-control" value="<?= $transaksi['berat']; ?>" placeholder="Berat (kg)">
                </div>

                <div class="form-group">
                    <input type="text" name="pcs_pakaian" id="pcs_pakaian" class="form-control" value="<?= $transaksi['pcs_pakaian']; ?>" placeholder="Total Pakaian">
                </div>

                <div class="form-group">
                    <input type="number" name="rak" id="rak" class="form-control" value="<?= $transaksi['rak']; ?>" placeholder="No. Rak Pakaian">
                </div>

                <div class="form-group">
                    <input type="number" name="jarak" id="jarak" class="form-control" value="<?= $transaksi['jarak']; ?>" placeholder="Masukkan Jarak (km)">
                </div>

                <div class="form-group">
                    <label for="tgl_diterima">Tanggal Diterima</label>
                    <input type="datetime-local" name="tgl_diterima" class="form-control" value="<?= isset($transaksi['tgl_diterima']) ? date('Y-m-d\TH:i', strtotime($transaksi['tgl_diterima'])) : ''; ?>">
                </div>

                <div class="form-group">
                    <input type="number" name="grand_total" id="grand_total" class="form-control" value="<?= $transaksi['grand_total'] ?>" placeholder="Total harga">
                </div>

                <div class="form-group" hidden>
                    <input type="text" name="tgl_masuk" value="<?= $tgl_masuk; ?>" class="form-control" placeholder="Tanggal Masuk" readonly>
                </div>

                <div class="form-group">
                    <select name="bayar" class="form-control">
                        <?php
                        if ($transaksi['bayar'] == "Lunas") { ?>
                            <option value="Lunas" selected> Lunas</option>
                            <option value="Belum Lunas"> Belum Lunas</option>
                        <?php } else { ?>
                            <option value="Lunas"> Lunas</option>
                            <option value="Belum Lunas" selected> Belum Lunas</option>
                        <?php }
                        ?>
                    </select>
                </div>

                <div class="form-group" hidden>
                    <input type="text" name="status" value="Baru" class="form-control" placeholder="Status" readonly>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="background-color: #3B6026;"> Update</button>
                    <a href="<?= base_url() ?>user/riwayat_pesanan" class="btn btn-danger"> Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>
    $('#paket').change(function() {
        var kode_paket = $(this).val();

        $.ajax({
            url: '<?= base_url() ?>admin/getHargaPaket',
            type: 'POST',
            data: { kode_paket: kode_paket },
            dataType: 'json',
            success: function(response) {
                if(response.harga_paket) {
                    $('#harga').val(response.harga_paket);
                    calculateTotal(); // Recalculate total if the price changes
                } else {
                    $('#harga').val(0); // Set to 0 if no data found
                }
            }
        });
    });

    $('#berat').on('keyup change', function() {
        calculateTotal();
    });

    function calculateTotal() {
        var berat = $('#berat').val();
        var harga = $('#harga').val();
        var total = berat * harga;
        $('#grand_total').val(total);
    }
</script>
