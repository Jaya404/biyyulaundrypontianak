<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('m_paket');
        $this->load->model('m_transaksi');
        $this->load->model('m_dashboard');
        $this->load->model('m_pewangi');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['total_konsumen'] = $this->m_dashboard->total_konsumen();
        $data['transaksi_baru'] = $this->m_dashboard->transaksi_baru();
        $data['total_transaksi'] = $this->m_dashboard->total_transaksi();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }

    public function role()
    {
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
    }

    public function addRole()
    {
        // Set validation rules
        $this->form_validation->set_rules('role', 'Role', 'required|trim');
    
        if ($this->form_validation->run() == false) {
            // Jika validasi gagal, redirect kembali ke halaman role
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Role name is required!</div>');
            redirect('admin/role');
        } else {
            // Ambil data dari input
            $role_name = $this->input->post('role');
            $data = [
                'role' => $role_name
            ];
    
            // Insert data ke database
            $this->db->insert('user_role', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New role added!</div>');
            redirect('admin/role');
        }
    }

    public function editRole($role_id)
    {
        $data['title'] = 'Edit Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/edit-role', $data); // Buat view baru untuk edit role
        $this->load->view('templates/footer');
    }

    public function updateRole()
    {
        $role_id = $this->input->post('role_id');
        $role_name = $this->input->post('role');

        $this->db->set('role', $role_name);
        $this->db->where('id', $role_id);
        $this->db->update('user_role');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Role Updated!</div>');
        redirect('admin/role');
    }

    public function deleteRole($role_id)
    {
        $this->db->delete('user_role', ['id' => $role_id]);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Role Deleted!</div>');
        redirect('admin/role');
    }

    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer');
    }

    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access Changed!</div>');
    }

    public function v_paket()
    {
        $data['title'] = 'Data Paket';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['paket'] = $this->m_paket->getDataPaket();
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/v_paket', $data);
        $this->load->view('templates/footer');
    }
    
    public function t_paket()
    {
        $data['title'] = 'Tambah Paket';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['paket'] = $this->m_paket->getDataPaket();
        $data['kode_paket'] = $this->m_paket->generate_kode_paket();
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/t_paket', $data);
        $this->load->view('templates/footer');
    }
    
    public function simpan()
    {
        $data = array(
            'kode_paket' => $this->input->post('kode_paket'),
            'nama_paket' => $this->input->post('nama_paket'),
            'harga_paket' => $this->input->post('harga_paket'),
        );
    
        $query = $this->db->insert('paket', $data);
    
        if ($query) {
            $this->session->set_flashdata('info', 'Data paket berhasil disimpan');
            redirect('admin/v_paket');
        }
    }
    
    public function e_paket($kode_paket)
    {
        $data['title'] = 'Edit Paket';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['data'] = $this->m_paket->edit($kode_paket);
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/e_paket', $data);
        $this->load->view('templates/footer');
    }
    
    public function delete($kode_paket)
    {
        $this->m_paket->delete($kode_paket);
        $this->session->set_flashdata('info', 'Data paket berhasil dihapus');
        redirect('admin/v_paket');
    }
    
    public function update()
    {
        $kode_paket = $this->input->post('kode_paket');
        $data = array(
            'nama_paket' => $this->input->post('nama_paket'),
            'harga_paket' => $this->input->post('harga_paket'),
        );
    
        $query = $this->m_paket->update($kode_paket, $data);
    
        if ($query) {
            $this->session->set_flashdata('info', 'Data paket berhasil diupdate');
            redirect('admin/v_paket');
        }
    }
    



    //Data Transaksi

    public function t_transaksi()
    {
        $data['title'] = 'Tambah Transaksi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['konsumen'] = $this->db->get('konsumen')->result();
        $data['paket'] = $this->db->get('paket')->result();
        
        // Ambil data pewangi dengan query SELECT * FROM pewangi
        $data['pewangi'] = $this->db->get('pewangi')->result();
    
        // Tambahkan debugging untuk memastikan data pewangi benar-benar diambil
        if (empty($data['pewangi'])) {
            echo "Data pewangi tidak ditemukan di database.";
            die();
        }
    
        $data['kode_transaksi'] = $this->m_transaksi->generateKode();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/t_transaksi', $data);
        $this->load->view('templates/footer');
    }
    
    


    public function getHargaPaket()
    {
        $kode_paket = $this->input->post('kode_paket');
        $data = $this->m_transaksi->getHargaPaket($kode_paket);
        if ($data) {
            echo json_encode($data);
        } else {
            echo json_encode(['harga_paket' => 0]); // Default value if not found
        }
    }


    public function simpan_transaksi()
    {
        $data = array(
            'kode_transaksi' => $this->input->post('kode_transaksi'),
            'kode_konsumen' => $this->input->post('kode_konsumen'),
            'kode_paket' => $this->input->post('kode_paket'),
            'kode_pewangi' => $this->input->post('kode_pewangi'), // Tambahkan pewangi
            'tgl_masuk' => $this->input->post('tgl_masuk'),
            'tgl_ambil' => '',
            'tgl_diterima' => $this->input->post('tgl_diterima'),
            'berat' => $this->input->post('berat'),
            'pcs_pakaian' => $this->input->post('pcs_pakaian'),
            'rak' => $this->input->post('rak'),
            'grand_total' => $this->input->post('grand_total'),
            'bayar' => $this->input->post('bayar'),
            'status' => $this->input->post('status')
        );
    
        $query = $this->db->insert('transaksi', $data);
        if ($query == true) {
            $this->session->set_flashdata('info', 'Data Transaksi Berhasil Disimpan');
            redirect('admin/t_transaksi', 'refresh');
        }
    }
    
    

    public function update_status()
    {
        $kode_transaksi = $this->input->post('kt');
        $status = $this->input->post('stt');
        $tgl_ambil = date('Y-m-d h:i:s');
        $status_bayar = 'Lunas';

        if ($status == "Baru" or $status == "Proses") {
            $this->m_transaksi->update_status($kode_transaksi, $status);
        } else {
            $this->m_transaksi->update_status1($kode_transaksi, $status, $tgl_ambil, $status_bayar);
        }
    }
    
    public function edit_transaksi($kode_transaksi)
    {
        $data['title'] = 'Edit Transaksi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['transaksi'] = $this->m_transaksi->edit_transaksi($kode_transaksi);
        $data['konsumen'] = $this->db->get('konsumen')->result();
        $data['paket'] = $this->db->get('paket')->result();
        $data['pewangi'] = $this->m_transaksi->getAllPewangi();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/edit_transaksi', $data);
        $this->load->view('templates/footer');
    }

    public function update_transaksi()
    {
        $kode_transaksi = $this->input->post('kode_transaksi');
        $data = array(
            'kode_transaksi' => $this->input->post('kode_transaksi'),
            'kode_konsumen' => $this->input->post('kode_konsumen'),
            'kode_paket' => $this->input->post('kode_paket'),
            'kode_pewangi' => $this->input->post('kode_pewangi'),
            'tgl_masuk' => $this->input->post('tgl_masuk'),
            'tgl_ambil' => '',
            'tgl_diterima' => $this->input->post('tgl_diterima'),
            'berat' => $this->input->post('berat'),
            'pcs_pakaian' => $this->input->post('pcs_pakaian'),
            'rak' => $this->input->post('rak'),
            'grand_total' => $this->input->post('grand_total'),
            'bayar' => $this->input->post('bayar'),
            'status' => $this->input->post('status')
        );

        $query = $this->m_transaksi->update_transaksi($kode_transaksi, $data);
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data Transaksi Berhasil Diupdate');
            redirect('user/riwayat_pesanan', 'refresh');
        }
    }

    public function nota($kode_transaksi)
    {
        $data['title'] = "Nota Laundry";
        $data['row'] = $this->m_transaksi->getRiwayatById($kode_transaksi);
        
        // Load the Nota view
        $this->load->view('admin/nota', $data);
    }

    public function delete_transaksi($kode_transaksi)
    {
        $this->m_transaksi->delete_transaksi($kode_transaksi);
        $this->session->set_flashdata('info', 'Data transaksi berhasil dihapus!');
        redirect('user/riwayat_pesanan');
    }

    public function v_pewangi()
    {
        $data['title'] = 'Data Pewangi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pewangi'] = $this->m_pewangi->getAllPewangi();
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/v_pewangi', $data);
        $this->load->view('templates/footer');
    }

    public function t_pewangi()
    {
        $data['title'] = 'Tambah Pewangi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kode_pewangi'] = 'PW' . time(); // Generate kode_pewangi otomatis
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/t_pewangi', $data);
        $this->load->view('templates/footer');
    }

    public function simpan_pewangi()
    {
        $data = [
            'kode_pewangi' => $this->input->post('kode_pewangi'),
            'nama_pewangi' => $this->input->post('nama_pewangi')
        ];
        $this->m_pewangi->simpanPewangi($data);
        $this->session->set_flashdata('info', 'Data pewangi berhasil disimpan');
        redirect('admin/v_pewangi');
    }

    public function delete_pewangi($kode_pewangi)
    {
        if ($this->m_pewangi->deletePewangi($kode_pewangi)) {
            $this->session->set_flashdata('info', 'Data pewangi berhasil dihapus');
        } else {
            $this->session->set_flashdata('info', 'Data pewangi gagal dihapus');
        }
        redirect('admin/v_pewangi');
    }

    public function e_pewangi($kode_pewangi)
    {
        $data['title'] = 'Edit Pewangi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pewangi'] = $this->m_pewangi->getPewangiByKode($kode_pewangi);
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/e_pewangi', $data);
        $this->load->view('templates/footer');
    }

    public function update_pewangi() {
        // Ambil data dari form
        $kode_pewangi = $this->input->post('kode_pewangi');
        $nama_pewangi = $this->input->post('nama_pewangi');
    
        // Siapkan data untuk update
        $data = [
            'nama_pewangi' => $nama_pewangi
        ];
    
        // Update data pewangi berdasarkan kode_pewangi
        $this->m_pewangi->updatePewangi($kode_pewangi, $data);
    
        // Set pesan berhasil
        $this->session->set_flashdata('info', 'Data Pewangi berhasil diubah!');
    
        // Redirect kembali ke halaman daftar pewangi
        redirect('admin/v_pewangi');
    }




}
