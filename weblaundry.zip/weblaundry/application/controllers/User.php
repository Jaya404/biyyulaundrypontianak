<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('m_konsumen');
        $this->load->model('m_transaksi');
        $this->load->model('m_dashboard_laundry');
    }

    public function index()
    {
        $data['title'] = 'Profil Saya';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }

    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            //cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated!</div>');
            redirect('user');
        }
    }

    public function changePassword()
    {
        $data['title'] = 'Ubah Password';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[7]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[7]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong current password</div>');
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New password cannot be the same as current password</div>');
                    redirect('user/changepassword');
                } else {
                    //paswword sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password berhasil diubah!</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }

    public function v_konsumen()
    {
        $data['title'] = 'Pesan Antar Jemput';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['konsumen'] = $this->m_konsumen->getAllDataKonsumen();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/v_konsumen', $data);
        $this->load->view('templates/footer');
    }

    public function t_konsumen()
    {
        $data['title'] = 'Pesan Antar Jemput';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['kode_konsumen'] = $this->m_konsumen->generate_kode_konsumen();
        $data['konsumen'] = $this->m_konsumen->getAllDataKonsumen();
        $data['paket'] = $this->db->get('paket')->result(); 
        $data['pewangi'] = $this->db->get('pewangi')->result();
        $this->db->join('konsumen', 'user.kode_konsumen = konsumen.kode_konsumen', 'left');
        $this->db->join('user', 'konsumen.name = user.name', 'left');
        

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/t_konsumen', $data);
        $this->load->view('templates/footer');
    }

    public function simpan()
    {
        $this->form_validation->set_rules('no_telp', 'Nomor Telepon', 'required|trim|max_length[14]');
    
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">' . validation_errors() . '</div>');
            redirect('user/t_konsumen');
        } else {
            $data = array(
                'kode_konsumen' => $this->input->post('kode_konsumen'),
                'nama_konsumen' => $this->input->post('nama_konsumen'),
                'alamat_konsumen' => $this->input->post('alamat_konsumen'),
                'no_telp' => $this->input->post('no_telp'),
                'kode_paket' => $this->input->post('kode_paket'),
                'kode_pewangi' => $this->input->post('kode_pewangi'),
                'tgl_pesan' => $this->input->post('tgl_pesan'), // Tambahkan ini
                'status_kons' => 'Baru' // Tambahkan ini
            );
            $query = $this->db->insert('konsumen', $data);
            if ($query) {
                $this->session->set_flashdata('message','Data Anda Berhasil Disimpan, Pesanan Anda Akan Segera Di Proses');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Gagal menyimpan data konsumen</div>');
            }
            redirect('user/v_konsumen');
        }
    }
    




    public function edit_konsumen($id)
    {
        $data['title'] = 'Edit Antar Jemput';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['konsumen'] = $this->m_konsumen->edit($id); // Pastikan model ini mengembalikan status_kons
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/edit_konsumen', $data);
        $this->load->view('templates/footer');
    }
    

    public function update()
    {
        $this->form_validation->set_rules('no_telp', 'Nomor Telepon', 'required|trim|max_length[14]');
    
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">' . validation_errors() . '</div>');
            redirect('user/edit_konsumen/' . $this->input->post('kode_konsumen'));
        } else {
            $kode_konsumen = $this->input->post('kode_konsumen');
            $data = array(
                'kode_konsumen' => $this->input->post('kode_konsumen'),
                'nama_konsumen' => $this->input->post('nama_konsumen'),
                'alamat_konsumen' => $this->input->post('alamat_konsumen'),
                'no_telp' => $this->input->post('no_telp'),
                'status_kons' => $this->input->post('status_kons') // Tambahkan ini
            );
            $query = $this->m_konsumen->update($kode_konsumen, $data);
            if ($query) {
                $this->session->set_flashdata('message', 'Data Konsumen Berhasil Di Update');
            } else {
                $this->session->set_flashdata('message', 'Gagal memperbarui data konsumen');
            }
            redirect('user/v_konsumen');
        }
    }
    




    public function delete($id)
    {
        $query = $this->m_konsumen->delete($id);
        if ($query = true) {
            $this->session->set_flashdata('info', 'Data Konsumen Berhasil Di Hapus');
            redirect('user/v_konsumen');
        }
    }

    public function riwayat_pesanan()
    {
        $data['title'] = 'Riwayat Pesanan Laundry';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['riwayat'] = $this->m_transaksi->getAllRiwayat();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/riwayat_pesanan', $data);
        $this->load->view('templates/footer');
    }

    public function edit_pesanan()
    {
        $data['title'] = 'Edit Pesanan Laundry';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/edit_pesanan', $data);
        $this->load->view('templates/footer');
    }

    public function status_konsumen()
    {
        $kode_konsumen = $this->input->post('kode_konsumen');
        $status_kons = $this->input->post('status_kons');
        
        $this->m_konsumen->update_status_konsumen($kode_konsumen, $status_kons);
        
        echo json_encode(['status' => 'success', 'message' => 'Status berhasil diperbarui']);
    }
    
    public function delete_konsumen()
    {
        $kode_konsumen = $this->input->post('kode_konsumen');

        // Panggil model untuk menghapus data konsumen berdasarkan kode_konsumen
        $this->m_konsumen->delete($kode_konsumen);

        // Kirimkan respons sukses
        echo json_encode(['status' => 'success']);
    }

    public function upload_image()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $upload_image = $_FILES['image']['name'];
        if ($upload_image) {
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/img/dashboard/';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {
                $image_name = $this->upload->data('file_name');
                $this->m_dashboard_laundry->save_image($image_name);
                $this->session->set_flashdata('message', '<div class="alert alert-success">Image uploaded successfully!</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">' . $this->upload->display_errors() . '</div>');
            }
        }
        redirect('user/dashboard_laundry');
    }

    public function dashboard_laundry()
    {
        $data['title'] = 'Dashboard Laundry';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['images'] = $this->m_dashboard_laundry->get_all_images();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/dashboard_laundry', $data);
        $this->load->view('templates/footer');
    }

    public function delete_image($image_id)
    {
        // Retrieve the image name from the database by image ID
        $image = $this->db->get_where('dashboard_images', ['id' => $image_id])->row_array();

        if ($image) {
            // Path to the image file
            $image_path = './assets/img/dashboard/' . $image['image_name'];

            // Check if the file exists, and delete it from the directory
            if (file_exists($image_path)) {
                unlink($image_path);
            }

            // Delete the image record from the database
            $this->db->delete('dashboard_images', ['id' => $image_id]);

            // Set a success message
            $this->session->set_flashdata('message', '<div class="alert alert-success">Image deleted successfully!</div>');
        } else {
            // Set an error message if image not found
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Image not found!</div>');
        }

        // Redirect back to the dashboard
        redirect('user/dashboard_laundry');
    }

    public function edit_image($image_id)
    {
        // Retrieve the current image record by image ID
        $image = $this->db->get_where('dashboard_images', ['id' => $image_id])->row_array();

        if ($image) {
            // Form for editing the image
            $data['title'] = 'Edit Image';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['image'] = $image;

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit_image', $data);  // View for editing image
            $this->load->view('templates/footer');
        } else {
            // If image not found, redirect with an error message
            $this->session->set_flashdata('message', '<div class="alert alert-danger">Image not found!</div>');
            redirect('user/dashboard_laundry');
        }
    }

    public function update_image($image_id)
    {
        // Retrieve the image record from the database
        $image = $this->db->get_where('dashboard_images', ['id' => $image_id])->row_array();

        if ($image) {
            // Configuration for file upload
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/img/dashboard/';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {
                // Delete old image from the server
                $old_image_path = './assets/img/dashboard/' . $image['image_name'];
                if (file_exists($old_image_path)) {
                    unlink($old_image_path);
                }

                // Get the new image file name
                $image_name = $this->upload->data('file_name');

                // Update the image in the database
                $this->db->update('dashboard_images', ['image_name' => $image_name], ['id' => $image_id]);

                // Set success message
                $this->session->set_flashdata('message', '<div class="alert alert-success">Image updated successfully!</div>');
            } else {
                // If upload fails, show error message
                $this->session->set_flashdata('message', '<div class="alert alert-danger">' . $this->upload->display_errors() . '</div>');
            }
        }

        // Redirect to the dashboard after the update
        redirect('user/dashboard_laundry');
    }

    
}
