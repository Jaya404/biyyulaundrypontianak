<?php
class M_pewangi extends CI_Model {

    public function getAllPewangi()
    {
        $this->db->order_by('kode_pewangi', 'DESC'); // Mengurutkan berdasarkan kode_pewangi dari yang terbesar
        return $this->db->get('pewangi')->result();
    }
    

    public function simpanPewangi($data) {
        $this->db->insert('pewangi', $data);
    }

    public function deletePewangi($kode_pewangi)
    {
        $this->db->where('kode_pewangi', $kode_pewangi);
        return $this->db->delete('pewangi');
    }

    public function getPewangiByKode($kode_pewangi) {
        return $this->db->get_where('pewangi', ['kode_pewangi' => $kode_pewangi])->row();
    }

    public function updatePewangi($kode_pewangi, $data) {
        $this->db->where('kode_pewangi', $kode_pewangi);
        $this->db->update('pewangi', $data);
    }    
    
}
