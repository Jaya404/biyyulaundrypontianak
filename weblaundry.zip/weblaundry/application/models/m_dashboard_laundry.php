<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_dashboard_laundry extends CI_Model
{
    // Fungsi untuk menyimpan data gambar ke database
    public function save_image($image_name)
    {
        $data = [
            'image_name' => $image_name
        ];
        return $this->db->insert('dashboard_images', $data);
    }

    // Fungsi untuk mengambil semua data gambar dari database
    public function get_all_images()
    {
        return $this->db->get('dashboard_images')->result_array();
    }
}
?>
