<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_transaksi extends CI_Model
{
    public function getHargaPaket($kode_paket)
    {
        $this->db->where('kode_paket', $kode_paket);
        return $this->db->get('paket')->row_array();
    }

    public function generateKode()
    {
        $this->db->select('RIGHT(transaksi.kode_transaksi,3) as kode', false);
        $this->db->order_by('kode_transaksi', 'desc');
        $this->db->limit(1);
        $query = $this->db->get('transaksi');
        if ($query->num_rows() > 0) {
            $data = $query->row();
            $kode = intval($data->kode) + 1;
        } else {
            $kode = 1;
        }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodejadi = "" . $kodemax;
        return $kodejadi;
    }

    public function getAllRiwayat()
    {
        $this->db->order_by('tgl_pesan', 'DESC');
        $this->db->select('transaksi.*, konsumen.nama_konsumen, konsumen.alamat_konsumen, konsumen.no_telp, paket.nama_paket');
        $this->db->from('transaksi');
        $this->db->join('konsumen', 'transaksi.kode_konsumen = konsumen.kode_konsumen', 'left');
        $this->db->join('paket', 'transaksi.kode_paket = paket.kode_paket', 'left');
        // $this->db->join('pewangi', 'transaksi.kode_pewangi = pewangi.kode_pewangi', 'left'); // Fixed the join condition
        return $this->db->get()->result();
    }

    public function edit_transaksi($kode_transaksi)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->join('konsumen', 'transaksi.kode_konsumen = konsumen.kode_konsumen', 'left');
        $this->db->join('paket', 'transaksi.kode_paket = paket.kode_paket', 'left');
        $this->db->where('kode_transaksi', $kode_transaksi);
        return $this->db->get()->row_array();
    }

    public function delete_transaksi($kode_transaksi)
    {
        $this->db->where('kode_transaksi', $kode_transaksi);
        $this->db->delete('transaksi');
    }


    public function update_status($kode_transaksi, $status)
    {
        $this->db->set('status', $status);
        $this->db->where('kode_transaksi', $kode_transaksi);
        $this->db->update('transaksi');
    }

    public function update_status1($kode_transaksi, $status, $tgl_ambil, $status_bayar)
    {
        $this->db->set('status', $status);
        $this->db->set('tgl_ambil', $tgl_ambil);
        $this->db->set('bayar', $status_bayar);
        $this->db->where('kode_transaksi', $kode_transaksi);
        $this->db->update('transaksi');
    }

    public function update_transaksi($kode_transaksi, $data)
    {
        $this->db->where('kode_transaksi', $kode_transaksi);
        $this->db->update('transaksi', $data);
    }

    public function getAllPewangi()
    {
        return $this->db->get('pewangi')->result();
    }

    public function getRiwayatById($kode_transaksi)
    {
        $this->db->select('transaksi.*, konsumen.nama_konsumen, konsumen.alamat_konsumen, konsumen.no_telp, paket.nama_paket, transaksi.kode_pewangi, transaksi.berat, transaksi.pcs_pakaian, transaksi.grand_total');
        $this->db->from('transaksi');
        $this->db->join('konsumen', 'transaksi.kode_konsumen = konsumen.kode_konsumen', 'left');
        $this->db->join('paket', 'transaksi.kode_paket = paket.kode_paket', 'left');
        $this->db->where('kode_transaksi', $kode_transaksi);
        return $this->db->get()->row();
    }
    


}
