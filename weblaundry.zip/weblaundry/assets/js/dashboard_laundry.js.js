// dashboard_laundry.js

function addImage() {
    $('#addImageModal').modal('show');
}

function deleteImage(imageId) {
    const confirmed = confirm("Apakah Anda yakin ingin menghapus gambar ini?");
    if (confirmed) {
        $.ajax({
            url: '<?= base_url("user/delete_image"); ?>',
            type: 'POST',
            data: { id: imageId },
            success: function(response) {
                if (response == 'success') {
                    alert("Gambar berhasil dihapus");
                    location.reload(); // Reload the page to show updated data
                } else {
                    alert("Gagal menghapus gambar");
                }
            },
            error: function() {
                alert("Terjadi kesalahan pada server.");
            }
        });
    }
}
